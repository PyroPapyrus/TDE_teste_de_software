import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Container } from '@mui/material';
import ListasPage from './pages/ListasPage';
import ListaDetail from './pages/ListaDetail';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import { ListasProvider } from './pages/ListasContext';
import { AuthProvider, useAuth } from './pages/AuthContext';

const PrivateRoute = ({ element }) => {
  const { currentUser } = useAuth();
  return currentUser ? element : <Navigate to="/login" />;
};

const App = () => {
  return (
    <AuthProvider>
      <ListasProvider>
        <Router>
          <Container>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/listas" element={<PrivateRoute element={<ListasPage />} />} />
              <Route path="/listas/:id" element={<PrivateRoute element={<ListaDetail />} />} />
              <Route path="/" element={<Navigate to="/listas" />} />
            </Routes>
          </Container>
        </Router>
      </ListasProvider>
    </AuthProvider>
  );
};

export default App;
