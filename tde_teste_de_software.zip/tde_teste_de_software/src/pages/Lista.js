import React, { useState } from "react";
import { TextField, Button, List, ListItem } from "@mui/material";
import Item from "./Item";
import { useListas } from "./ListasContext";

const Lista = ({ listaId, lista, editLista, deleteLista }) => {
  const [novoNome, setNovoNome] = useState(lista.nome);
  const { addItemToLista, editItemInLista, deleteItemFromLista } = useListas();

  const handleAddItem = async () => {
    try {
      await addItemToLista(listaId, "Novo Item");
    } catch (error) {
      console.error("Erro ao adicionar item:", error);
    }
  };

  const handleEditItem = async (itemId, novoNome) => {
    try {
      await editItemInLista(listaId, itemId, novoNome);
    } catch (error) {
      console.error("Erro ao editar item:", error);
    }
  };

  const handleDeleteItem = async (itemId) => {
    try {
      await deleteItemFromLista(listaId, itemId);
    } catch (error) {
      console.error("Erro ao excluir item:", error);
    }
  };

  return (
    <div>
      <TextField
        value={novoNome}
        onChange={(e) => setNovoNome(e.target.value)}
        onBlur={() => editLista(listaId, { ...lista, nome: novoNome })}
      />
      <Button onClick={() => deleteLista(listaId)}>Excluir Lista</Button>
      <List>
        {lista.itens.map((item, i) => (
          <ListItem key={item.id}>
            <Item
              index={i}
              item={item}
              editItem={(nome) => handleEditItem(item.id, nome)}
              deleteItem={() => handleDeleteItem(item.id)}
            />
          </ListItem>
        ))}
      </List>
      <Button onClick={handleAddItem}>Adicionar Item</Button>
    </div>
  );
};

export default Lista;
