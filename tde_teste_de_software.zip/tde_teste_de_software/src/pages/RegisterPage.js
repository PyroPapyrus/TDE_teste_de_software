import React, { useState } from 'react';
import { TextField, Button, Typography, Container, Box, Link } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig'; 

const RegisterPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleRegister = async () => {
    try {
      // Cria o usuário com email e senha
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Adiciona o documento do usuário no Firestore
      await setDoc(doc(db, `users/${user.uid}`), {
        email: user.email,
        createdAt: new Date(),
      });

      console.log('Usuário registrado:', user);
      navigate('/login');
    } catch (error) {
      console.error('Erro ao registrar usuário:', error);
      setError(error.message);
    }
  };

  return (
    <Container component="main" maxWidth="xs">
      <Box
        sx={{
          marginTop: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h1" variant="h5" color="white">
          Registrar-se
        </Typography>
        <TextField
          margin="normal"
          required
          fullWidth
          label="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="email"
          autoFocus
          sx={{
            input: {
              color: "white",
            },
            label: {
              color: "lightgray",
            },
            fieldset: {
              borderColor: "white",
            },
            "&:hover fieldset": {
              borderColor: "lightgray",
            },
            "&.Mui-focused fieldset": {
              borderColor: "green",
            },
          }}
        />
        <TextField
          margin="normal"
          required
          fullWidth
          label="Senha"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
          sx={{
            input: {
              color: "white",
            },
            label: {
              color: "lightgray",
            },
            fieldset: {
              borderColor: "white",
            },
            "&:hover fieldset": {
              borderColor: "lightgray",
            },
            "&.Mui-focused fieldset": {
              borderColor: "green",
            },
          }}
        />
        {error && <Typography color="error">{error}</Typography>}
        <Button
          type="submit"
          fullWidth
          variant="contained"
          sx={{ mt: 3, mb: 2 }}
          onClick={handleRegister}
        >
          Registrar
        </Button>
        <Typography variant="body2" color="white" align="center" style={{ marginTop: '16px'}}>
        Já possui uma conta?{' '}
        <Link
          component="button"
          variant="body2"
          onClick={() => navigate('/')}
          sx={{
            color: 'white', 
            '&:hover': {
              color: 'blue',
            },
          }}
        >
          Login
        </Link>
      </Typography>
      </Box>
    </Container>
  );
};

export default RegisterPage;
