import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { signOut } from 'firebase/auth';
import {
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Typography,
  TextField,
  IconButton,
  Snackbar,
  Alert
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import EditIcon from "@mui/icons-material/Edit";
import { useListas } from "./ListasContext";
import { auth, db } from "../firebaseConfig";
import { doc, updateDoc, deleteDoc } from "firebase/firestore";

const ListasPage = () => {
  const { listas, setListas, addLista } = useListas();
  const [novoNome, setNovoNome] = useState("");
  const [editIndex, setEditIndex] = useState(null);
  const [editNome, setEditNome] = useState("");
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState("info");
  const navigate = useNavigate();

  const handleAddLista = async () => {
    if (novoNome.trim() === "") {
      setSnackbarMessage("O nome da lista não pode estar vazio.");
      setSnackbarSeverity("warning");
      setOpenSnackbar(true);
      return;
    }

    const novaLista = {
      nome: novoNome,
      itens: [],
      concluido: false
    };

    try {
      await addLista(novaLista); 
      setNovoNome(""); 
      setSnackbarMessage("Lista adicionada com sucesso!");
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Erro ao adicionar lista:', error);
      setSnackbarMessage("Erro ao adicionar lista. Tente novamente.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const handleUpdateListaNome = async (index) => {
    if (editNome.trim() === "") {
      setSnackbarMessage("O nome da lista não pode estar vazio.");
      setSnackbarSeverity("warning");
      setOpenSnackbar(true);
      return;
    }

    const listaId = listas[index].id;
    const listaRef = doc(db, `users/${auth.currentUser.uid}/lists/${listaId}`);
    
    try {
      await updateDoc(listaRef, { nome: editNome });
      const novasListas = [...listas];
      novasListas[index].nome = editNome;
      setListas(novasListas);
      setEditIndex(null);
      setEditNome("");
      setSnackbarMessage("Nome da lista atualizado com sucesso!");
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Erro ao atualizar nome da lista:', error);
      setSnackbarMessage("Erro ao atualizar nome da lista. Tente novamente.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const handleToggleConcluido = async (index) => {
    const novasListas = [...listas];
    novasListas[index].concluido = !novasListas[index].concluido;
    setListas(novasListas);

    const listaId = listas[index].id;
    const listaRef = doc(db, `users/${auth.currentUser.uid}/lists/${listaId}`);
    
    try {
      await updateDoc(listaRef, { concluido: novasListas[index].concluido });
    } catch (error) {
      console.error('Erro ao atualizar status da lista:', error);
      setSnackbarMessage("Erro ao atualizar status da lista. Tente novamente.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const handleDeleteLista = async (index) => {
    const listaId = listas[index].id;
    const listaRef = doc(db, `users/${auth.currentUser.uid}/lists/${listaId}`);

    try {
      await deleteDoc(listaRef);
      const novasListas = listas.filter((_, i) => i !== index);
      setListas(novasListas);
      setSnackbarMessage("Lista excluída com sucesso!");
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Erro ao excluir lista:', error);
      setSnackbarMessage("Erro ao excluir lista. Tente novamente.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <div>
      <Typography
        variant="h4"
        gutterBottom
        style={{ color: "white", textShadow: "2px 2px 4px rgba(0, 0, 0, 0.5)" }}
      >
        Minhas Listas
      </Typography>
      <Grid container spacing={3}>
        {listas.map((lista, index) => (
          <Grid item xs={12} sm={6} md={4} key={lista.id}>
            <Card
              style={{
                backgroundColor: lista.concluido
                  ? "#d3ffd3"
                  : "rgba(69, 69, 69)",
              }}
            >
              <CardContent>
                {editIndex === index ? (
                  <div>
                    <TextField
                      value={editNome}
                      onChange={(e) => setEditNome(e.target.value)}
                      fullWidth
                      sx={{
                        input: { color: "white" },
                        label: { color: "lightgray" },
                        fieldset: { borderColor: "lightblue" },
                        "&:hover fieldset": { borderColor: "lightgray" },
                        "&.Mui-focused fieldset": { borderColor: "lightblue" },
                      }}
                      InputLabelProps={{ style: { color: "lightgray" } }}
                    />
                    <div style={{ marginTop: 8 }}>
                      <Button
                        onClick={() => handleUpdateListaNome(index)}
                        sx={{ color: "white", marginRight: 2 }}
                      >
                        Confirmar
                      </Button>
                      <Button
                        onClick={() => {
                          setEditIndex(null);
                          setEditNome("");
                        }}
                        sx={{ color: "white" }}
                      >
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Typography variant="h5" sx={{ color: "white" }}>
                    {lista.nome}
                  </Typography>
                )}
              </CardContent>
              <CardActions>
                <Button
                  size="small"
                  onClick={() => navigate(`/listas/${lista.id}`)}
                  sx={{
                    color: "white",
                    "&:hover": {
                      backgroundColor: "rgba(255, 255, 255, 0.4)",
                      color: "black",
                      transition: "background-color"
                    }
                  }}
                >
                  Abrir
                </Button>
                <Button
                  size="small"
                  onClick={() => handleDeleteLista(index)}
                  sx={{
                    color: "white",
                    "&:hover": {
                      backgroundColor: "rgba(255, 0, 0, 0.4)", 
                      color: "red", 
                      transition: "background-color"
                    }
                  }}
                >
                  Excluir
                </Button>
                <IconButton
                  size="small"
                  onClick={() => {
                    setEditIndex(index);
                    setEditNome(lista.nome);
                  }}
                >
                  <EditIcon style={{ color: "white" }} />
                </IconButton>
                <IconButton
                  size="small"
                  onClick={() => handleToggleConcluido(index)}
                >
                  <CheckCircleIcon
                    sx={{
                      color: lista.concluido ? "green" : "white",
                      opacity: lista.concluido ? 1 : 0.5,
                    }}
                  />
                </IconButton>
              </CardActions>
            </Card>
          </Grid>
        ))}
        <Grid item xs={12} sm={6} md={4}>
          <Card style={{ backgroundColor: "rgba(69, 69, 69)" }}>
            <CardContent>
              <TextField
                label="Nova Lista"
                value={novoNome}
                onChange={(e) => setNovoNome(e.target.value)}
                fullWidth
                sx={{
                  input: { color: "white" },
                  label: { color: "lightgray" },
                  fieldset: { borderColor: "lightblue" },
                  "&:hover fieldset": { borderColor: "lightgray" },
                  "&.Mui-focused fieldset": { borderColor: "lightblue" },
                }}
                InputLabelProps={{ style: { color: "lightgray" } }}
              />
            </CardContent>
            <CardActions>
              <Button
                size="small"
                onClick={handleAddLista}
                sx={{
                  color: "white",
                  "&:hover": {
                    backgroundColor: "rgba(255, 255, 255, 0.4)", 
                    color: "black", 
                    transition: "background-color"
                  }
                }}
              >
                Adicionar Lista
              </Button>
            </CardActions>
          </Card>
        </Grid>
      </Grid>
      <Button
        onClick={handleLogout}
        sx={{
          color: "white",
          "&:hover": {
            backgroundColor: "rgba(0, 255, 255, 0.4)", 
            color: "blue", 
            transition: "background-color"
          }
        }}
      >
        Logout
      </Button>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbarSeverity}
          sx={{ width: '100%' }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </div>
  );
};

export default ListasPage;
