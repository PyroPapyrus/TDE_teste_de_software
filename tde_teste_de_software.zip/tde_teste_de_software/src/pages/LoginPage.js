import React, { useState } from 'react';
import { TextField, Button, Typography, Container, Box, Link } from '@mui/material';
import { auth } from '../firebaseConfig';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async (event) => {
    event.preventDefault(); 
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userId = userCredential.user.uid;

      localStorage.setItem('userId', userId);

      navigate('/listas'); 
    } catch (error) {
      console.error('Erro ao fazer login:', error);
      setError(error.message);
    }
  };

  return (
    <Container component="main" maxWidth="xs">
      <Box
        sx={{
          marginTop: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h1" variant="h5" color="white">
          Login
        </Typography>
        <form onSubmit={handleLogin}>
          <TextField
            margin="normal"
            required
            fullWidth
            label="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            autoFocus
            sx={{
                input: {
                  color: "white",
                },
                label: {
                  color: "lightgray",
                },
                fieldset: {
                  borderColor: "white",
                },
                "&:hover fieldset": {
                  borderColor: "lightgray",
                },
                "&.Mui-focused fieldset": {
                  borderColor: "green",
                },
              }}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            label="Senha"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            sx={{
                input: {
                  color: "white",
                },
                label: {
                  color: "lightgray",
                },
                fieldset: {
                  borderColor: "white",
                },
                "&:hover fieldset": {
                  borderColor: "lightgray",
                },
                "&.Mui-focused fieldset": {
                  borderColor: "green",
                },
              }}
          />
          {error && <Typography color="error">{error}</Typography>}
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
          >
            Login
          </Button>
          <Typography variant="body2" color="white" align="center" style={{ marginTop: '16px' }}>
        Não está registrado ainda?{' '}
        <Link
          component="button"
          variant="body2"
          onClick={() => navigate('/register')}
          sx={{
            color: 'white', 
            '&:hover': {
              color: 'blue',
            },
          }}
        >
          Registre-se aqui
        </Link>
      </Typography>
          
        </form>
      </Box>
    </Container>
  );
};

export default LoginPage;
