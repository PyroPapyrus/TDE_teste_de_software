import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, TextField, Button, List, ListItem, ListItemText, IconButton, Typography, Snackbar, Alert } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../firebaseConfig'; 
import { useAuth } from './AuthContext';

const ListaDetail = () => {
  const { id } = useParams();
  const { currentUser } = useAuth();
  const [lista, setLista] = useState(null);
  const [novoItem, setNovoItem] = useState("");
  const [editIndex, setEditIndex] = useState(null);
  const [editItemNome, setEditItemNome] = useState("");
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState("info");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchLista = async () => {
      const listaRef = doc(db, 'users', currentUser.uid, 'lists', id);
      try {
        const listaDoc = await getDoc(listaRef);
        if (listaDoc.exists()) {
          setLista(listaDoc.data());
        } else {
          console.log('Lista não encontrada');
        }
      } catch (error) {
        console.error('Erro ao buscar lista:', error);
      }
    };

    fetchLista();
  }, [id, currentUser]);

  if (!lista) return <div>Loading...</div>;

  const addItem = async () => {
    if (novoItem.trim() === "") {
      setSnackbarMessage("O nome do item não pode estar vazio.");
      setSnackbarSeverity("warning");
      setOpenSnackbar(true);
      return;
    }
    const novosItens = [...lista.itens, { nome: novoItem, concluido: false }];
    const listaRef = doc(db, 'users', currentUser.uid, 'lists', id);
    try {
      await updateDoc(listaRef, { itens: novosItens });
      setLista((prevLista) => ({ ...prevLista, itens: novosItens }));
      setNovoItem("");
      setSnackbarMessage("Item adicionado com sucesso!");
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Erro ao adicionar item:', error);
      setSnackbarMessage("Erro ao adicionar item. Tente novamente.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const updateItemNome = async (itemIndex) => {
    if (editItemNome.trim() === "") {
      setSnackbarMessage("O nome do item não pode estar vazio.");
      setSnackbarSeverity("warning");
      setOpenSnackbar(true);
      return;
    }
    const novosItens = [...lista.itens];
    novosItens[itemIndex].nome = editItemNome;
    const listaRef = doc(db, 'users', currentUser.uid, 'lists', id);
    try {
      await updateDoc(listaRef, { itens: novosItens });
      setLista((prevLista) => ({ ...prevLista, itens: novosItens }));
      setEditIndex(null);
      setEditItemNome("");
      setSnackbarMessage("Item atualizado com sucesso!");
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Erro ao atualizar item:', error);
      setSnackbarMessage("Erro ao atualizar item. Tente novamente.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const cancelEdit = () => {
    setEditIndex(null);
    setEditItemNome("");
  };

  const toggleItemConcluido = async (itemIndex) => {
    const novosItens = [...lista.itens];
    novosItens[itemIndex].concluido = !novosItens[itemIndex].concluido;
    const listaRef = doc(db, 'users', currentUser.uid, 'lists', id);
    try {
      await updateDoc(listaRef, { itens: novosItens });
      setLista((prevLista) => ({ ...prevLista, itens: novosItens }));
    } catch (error) {
      console.error('Erro ao atualizar item:', error);
      setSnackbarMessage("Erro ao atualizar item. Tente novamente.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const deleteItem = async (itemIndex) => {
    const novosItens = lista.itens.filter((_, i) => i !== itemIndex);
    const listaRef = doc(db, 'users', currentUser.uid, 'lists', id);
    try {
      await updateDoc(listaRef, { itens: novosItens });
      setLista((prevLista) => ({ ...prevLista, itens: novosItens }));
      setSnackbarMessage("Item excluído com sucesso!");
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Erro ao deletar item:', error);
      setSnackbarMessage("Erro ao excluir item. Tente novamente.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <Container>
      <Button onClick={() => navigate("/listas")} style={{ color: "white" }}>
        Voltar
      </Button>
      <Typography
        variant="h4"
        gutterBottom
        style={{ color: "white", textShadow: "2px 2px 4px rgba(0, 0, 0, 0.5)" }}
      >
        {lista.nome}
      </Typography>
      <List>
        {lista.itens.map((item, index) => (
          <ListItem
            key={index}
            style={{
              backgroundColor: item.concluido
                ? "#3CB371"
                : "rgba(69, 69, 69, 0.8)",
              marginBottom: "10px",
              borderRadius: "5px",
            }}
          >
            {editIndex === index ? (
              <TextField
                value={editItemNome}
                onChange={(e) => setEditItemNome(e.target.value)}
                fullWidth
                sx={{
                  input: {
                    color: "white",
                  },
                  label: {
                    color: "white", 
                  },
                  fieldset: {
                    borderColor: "white", 
                  },
                  "&:hover fieldset": {
                    borderColor: "lightgray", 
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "lightgray", 
                  },
                }}
              />
            ) : (
              <ListItemText
                primary={item.nome}
                style={{
                  color: "white",
                  textShadow: "1px 1px 2px rgba(0, 0, 0, 0.5)",
                }}
              />
            )}
            {editIndex === index ? (
              <>
                <Button
                  size="small"
                  onClick={() => updateItemNome(index)}
                  style={{ color: "white", marginRight: "10px" }}
                >
                  Confirmar
                </Button>
                <Button
                  size="small"
                  onClick={cancelEdit}
                  style={{ color: "white" }}
                >
                  Cancelar
                </Button>
              </>
            ) : (
              <>
                <IconButton
                  edge="end"
                  aria-label="delete"
                  onClick={() => deleteItem(index)}
                >
                  <DeleteIcon style={{ color: "white" }} />
                </IconButton>
                <IconButton
                  edge="end"
                  aria-label="edit"
                  onClick={() => {
                    setEditIndex(index);
                    setEditItemNome(item.nome);
                  }}
                >
                  <EditIcon style={{ color: "white" }} />
                </IconButton>
                <IconButton
                  edge="end"
                  aria-label="concluido"
                  onClick={() => toggleItemConcluido(index)}
                >
                  <CheckCircleIcon
                    sx={{
                      color: item.concluido ? "green" : "white",
                      opacity: item.concluido ? 1 : 0.5,
                    }}
                  />
                </IconButton>
              </>
            )}
          </ListItem>
        ))}
      </List>
      <TextField
        label="Novo Item"
        value={novoItem}
        onChange={(e) => setNovoItem(e.target.value)}
        fullWidth
        sx={{
          input: {
            color: "white", 
          },
          label: {
            color: "white", 
          },
          fieldset: {
            borderColor: "white", 
          },
          "&:hover fieldset": {
            borderColor: "lightgray",
          },
          "&.Mui-focused fieldset": {
            borderColor: "lightgray", 
          },
        }}
      />
      <Button
        onClick={addItem}
        style={{
          marginTop: "10px",
          backgroundColor: "rgba(80, 80, 80)",
          color: "lightblue"
        }}
      >
        Adicionar Item
      </Button>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbarSeverity}
          sx={{ width: '100%' }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default ListaDetail;
