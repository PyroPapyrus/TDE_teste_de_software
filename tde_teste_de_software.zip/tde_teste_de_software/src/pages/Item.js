import React, { useState } from "react";
import { TextField, Button } from "@mui/material";
import { db, auth } from "../firebaseConfig";
import { doc, updateDoc, deleteDoc } from "firebase/firestore";

const Item = ({ index, item, listId, itemId, editItem, deleteItem }) => {
  const [novoNome, setNovoNome] = useState(item.nome);

  const handleEdit = async () => {
    if (novoNome.trim() === "") {
      alert("O nome do item não pode estar vazio.");
      return;
    }
    
    try {
      const itemRef = doc(db, `users/${auth.currentUser.uid}/lists/${listId}/items/${itemId}`);
      await updateDoc(itemRef, { nome: novoNome });
      editItem(index, novoNome); 
    } catch (error) {
      console.error('Erro ao atualizar item:', error);
    }
  };

  const handleDelete = async () => {
    try {
      const itemRef = doc(db, `users/${auth.currentUser.uid}/lists/${listId}/items/${itemId}`);
      await deleteDoc(itemRef);
      deleteItem(); 
    } catch (error) {
      console.error('Erro ao excluir item:', error);
    }
  };

  return (
    <div>
      <TextField
        value={novoNome}
        onChange={(e) => setNovoNome(e.target.value)}
        onBlur={handleEdit}
      />
      <Button onClick={handleDelete}>Excluir Item</Button>
    </div>
  );
};

export default Item;
