import React, { createContext, useState, useContext, useEffect } from 'react';
import { db } from '../firebaseConfig';
import { useAuth } from './AuthContext';
import { collection, query, onSnapshot, addDoc, doc, updateDoc, deleteDoc } from 'firebase/firestore';

const ListasContext = createContext();

export const useListas = () => {
  return useContext(ListasContext);
};

export const ListasProvider = ({ children }) => {
  const { currentUser } = useAuth();
  const [listas, setListas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (currentUser) {
      const listasCollection = collection(db, `users/${currentUser.uid}/lists`);
      const q = query(listasCollection);

      const unsubscribe = onSnapshot(
        q,
        (querySnapshot) => {
          const listasData = querySnapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }));
          setListas(listasData);
          setLoading(false);
        },
        (error) => {
          console.error('Erro ao buscar listas:', error);
          setError(error);
          setLoading(false);
        }
      );

      return () => unsubscribe();
    } else {
      setListas([]);
      setLoading(false);
    }
  }, [currentUser]);

  const addLista = async (novaLista) => {
    if (currentUser) {
      try {
        await addDoc(collection(db, `users/${currentUser.uid}/lists`), novaLista);
      } catch (error) {
        console.error('Erro ao adicionar lista:', error);
        setError(error);
      }
    }
  };

  const addItemToLista = async (listaId, nome) => {
    if (currentUser) {
      try {
        await addDoc(collection(db, `users/${currentUser.uid}/lists/${listaId}/items`), { nome });
      } catch (error) {
        console.error('Erro ao adicionar item:', error);
        setError(error);
      }
    }
  };

  const editItemInLista = async (listaId, itemId, novoNome) => {
    if (currentUser) {
      try {
        const itemRef = doc(db, `users/${currentUser.uid}/lists/${listaId}/items/${itemId}`);
        await updateDoc(itemRef, { nome: novoNome });
      } catch (error) {
        console.error('Erro ao editar item:', error);
        setError(error);
      }
    }
  };

  const deleteItemFromLista = async (listaId, itemId) => {
    if (currentUser) {
      try {
        const itemRef = doc(db, `users/${currentUser.uid}/lists/${listaId}/items/${itemId}`);
        await deleteDoc(itemRef);
      } catch (error) {
        console.error('Erro ao excluir item:', error);
        setError(error);
      }
    }
  };

  return (
    <ListasContext.Provider value={{ listas, setListas, addLista, addItemToLista, editItemInLista, deleteItemFromLista, loading, error }}>
      {children}
    </ListasContext.Provider>
  );
};
