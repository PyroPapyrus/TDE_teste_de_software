// firebaseConfig.js

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Configurações do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAMyaPQePpri6FhHlxsil2DBVFbpljRnrE",
  authDomain: "projeto-de-listagem.firebaseapp.com",
  projectId: "projeto-de-listagem",
  storageBucket: "projeto-de-listagem.appspot.com",
  messagingSenderId: "32270160640",
  appId: "1:32270160640:web:2b54f08ddfa55ecbb8d9e5",
  measurementId: "G-M6FJD1SFE2"
};

// Inicialização do Firebase
const app = initializeApp(firebaseConfig);

// Exporta as instâncias de auth e db
export const auth = getAuth(app);
export const db = getFirestore(app);
